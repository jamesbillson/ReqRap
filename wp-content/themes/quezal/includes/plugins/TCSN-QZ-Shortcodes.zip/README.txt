=== TCSN-KR-Shortcodes ===
Contributors: Tansh
Tags: Shortcodes
Requires at least: 3.8
Tested up to: 3.9
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Creates Shortcodes.

== Description ==

Creates Shortcodes.

== Changelog ==

= 1.0.0 =
* Initial release.
